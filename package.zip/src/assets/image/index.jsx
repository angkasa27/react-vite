import MySelf from './MySelf.jpg'
import Mokletdev from './Mokletdev.jpg'
import SuratBahagia from './SuratBahagia.jpg'
import MySelfTrans from './MySelf.png'

const image = {
  MySelf,
  MySelfTrans,
  Mokletdev,
  SuratBahagia,
}

export default image
