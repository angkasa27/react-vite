export { default } from './Slider'
