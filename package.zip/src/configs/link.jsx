import { submitWhatsApp } from "../utils/url";

export const CONTACT = {
  INSTAGRAM: "http://instagram.com/mas.angkasa27",
  LINKEDIN: "https://www.linkedin.com/in/dimasangkasa/",
  GITHUB: "https://github.com/angkasa27",
  DRIBBBLE: "https://dribbble.com/angkasa27",
};
