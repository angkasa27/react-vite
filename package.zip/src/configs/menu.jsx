export const MENU = [
  { label: 'Home', href: '/#main', name: 'main' },
  { label: 'About', href: '/#about', name: 'about' },
  { label: 'Skills', href: '/#skills', name: 'skills' },
  { label: 'My Work', href: '/#project', name: 'project' },
  { label: 'Contact', href: '/#contact', name: 'contact' },
]
